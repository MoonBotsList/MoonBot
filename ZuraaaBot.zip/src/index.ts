import ZuraaaBot from './zuraaa-bot'
import 'reflect-metadata'

const zuraaaBot = new ZuraaaBot()
zuraaaBot.start()

export default zuraaaBot
