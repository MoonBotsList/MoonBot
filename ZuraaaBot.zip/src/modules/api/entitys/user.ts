export interface User{
  details: UserDetails
}

export interface UserDetails{
  description: string
}
